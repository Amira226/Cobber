/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author eliasnkuansambu
 */

public class Candy implements Cloneable, IProduct{
    
    //
    private String Name = "";
    public String GetProductName() { return Name; }
    public void SetProductName(String ProductName) { this.Name = ProductName; }

    private double Price = 0;
    public double GetProductPrice() { return Price; }
    public void SetProductPrice(int ProductPrice) { this.Price = ProductPrice; }

    public Candy() {}

    public Candy(String ProductName, double ProductPrice) {
        this.Name = ProductName;
        this.Price = ProductPrice;
    }
   
    @Override
    public Candy clone() throws CloneNotSupportedException {
        return (Candy) super.clone();
    }

    @Override
    public String DisplayProductName() {
        return GetProductName();
        
    }

    @Override
    public double DisplayProductPrice() {
        return GetProductPrice();
    }

}