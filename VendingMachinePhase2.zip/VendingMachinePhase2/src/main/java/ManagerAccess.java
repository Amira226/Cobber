
import java.util.Scanner;

/**
 * Manager Access
 * This is a bonus code page.
 * It provides the manager with the ability to withdraw or add cash from any of the machines.
 */

/**
 *
 * @author eliasnkuansambu
 */
public class ManagerAccess {
    
    //This method describes the process managers will go through to add/withdraw cash
    public static void processingManager(String slotCode)
    {
        Scanner input = new Scanner(System.in);
         double CHOICE;
        //Main switch code, controls the choices of the password
        switch(slotCode){
        
            case "Q": 
                break;
            
            case "PASSWORD":
               while (!slotCode.equals("Q")) {
                //Display the screen if the password is inserted
                System.out.print("\n");
                System.out.println("Which account you want to check?");
                System.out.println("\n");
                System.out.println("1. Candy Vending Machine.");
                System.out.println("2. Soda Vending Machine.");
                System.out.println("3. General Vending Machine.");
                System.out.println("4. All");
                System.out.println("Q. Go back to the previous menu");
                String choice = input.nextLine().trim();
                
                switch(choice){
        
                    case "Q": 
                        break;
                    //The first case   
                    case "1":
                            //Laying out the next choice
                        while (!choice.equals("Q")) {
                            System.out.println("The current total cash in this soda candy machine is  "+ CandyMachine.GetCandyCash());
                            System.out.println("Do you want to add an amount to this vault or want to withdraw some amount from it? ");
                            System.out.println("A. add");
                            System.out.println("W. withdraw");
                            System.out.println("Q. Go back to the previous menu");
                            choice = input.nextLine().toUpperCase().trim();
                            
                            switch (choice) {
                                case "A":
                                    {
                                        System.out.println("How much do you want to add?");
                                        choice = input.nextLine().toUpperCase().trim();
                                        CHOICE = TheStorePanel.TryParseDouble(choice);
                                        //accounting for exceptions and wrong values
                                        while(CHOICE<0)
                                        {
                                            System.out.println("To add to your chosen machine, you have to insert an amount greater or equal to zero. Try again!");
                                            System.out.println("How much do you want to add?");
                                            choice = input.nextLine().toUpperCase().trim();
                                            CHOICE = TheStorePanel.TryParseDouble(choice);
                                        }
                                        //Adding the cash
                                        CandyMachine.AddCandyCash(CHOICE);
                                        System.out.println("You added "+CHOICE+" and now, the total amount of cash in this vault is "+ CandyMachine.GetCandyCash()+"\n");
                                        break;
                                    }
                                case "W":
                                    {
                                        System.out.println("How much do you want to withdraw?");
                                        choice = input.nextLine().toUpperCase().trim();
                                        CHOICE = TheStorePanel.TryParseDouble(choice);
                                        //accounting for exceptions and wrong values
                                        while(CHOICE>CandyMachine.GetCandyCash()|| CHOICE<0)
                                        {
                                            System.out.println("You cannot withdraw an amount greater than what the machine has.");
                                            System.out.println("Please, insert an amount that is no greater than "+ CandyMachine.GetCandyCash()+" and no lesser than zero"+"\n");
                                            choice = input.nextLine().toUpperCase().trim();
                                            CHOICE = TheStorePanel.TryParseDouble(choice);
                                        }
                                        //Withdrawing cash
                                        CandyMachine.AddCandyCash(-CHOICE);
                                        System.out.println("You took "+CHOICE+" and now, the total amount of cash in this vault is "+ CandyMachine.GetCandyCash()+"\n");
                                        break;
                                    }
                                default:
                                    System.out.println("Please make one of the choices displayed here or press 'Q' to return to previous menu.");
                                    break;
                            }
                        }

                        
                    break; 
                    //For case 2
                    case "2":
                           while (!choice.equals("Q")) {
                               System.out.println("The current total cash in this soda candy machine is  "+ SodaMachine.GetSodaCash());
                               System.out.println("Do you want to add an amount to this vault or want to withdraw some amount from it? ");
                               System.out.println("A. add");
                               System.out.println("W. withdraw");
                               System.out.println("Q. Go back to the previous menu");
                               choice = input.nextLine().toUpperCase().trim();
                               switch (choice) {
                                   case "A":
                                       {
                                           System.out.println("How much do you want to add?");
                                           choice = input.nextLine().toUpperCase().trim();
                                           CHOICE = TheStorePanel.TryParseDouble(choice);
                                           while(CHOICE<0)
                                        {
                                            System.out.println("To add to your chosen machine, you have to insert an amount greater or equal to zero. Try again!");
                                            System.out.println("How much do you want to add?");
                                            choice = input.nextLine().toUpperCase().trim();
                                            CHOICE = TheStorePanel.TryParseDouble(choice);
                                        }
                                           //Adding cash
                                           SodaMachine.AddSodaCash(CHOICE);
                                           System.out.println("You added "+CHOICE+" and now, the total amount of cash in this vault is "+ SodaMachine.GetSodaCash()+"\n");
                                           break;
                                       }
                                   case "W":
                                       {
                                           System.out.println("How much do you want to withdraw?");
                                           choice = input.nextLine().toUpperCase().trim();
                                           CHOICE = TheStorePanel.TryParseDouble(choice);
                                           while(CHOICE>SodaMachine.GetSodaCash() || CHOICE<0)
                                           {
                                               System.out.println("You cannot withdraw an amount greater than what the machine has.");
                                               System.out.println("Please, insert an amount that is no greater than "+ SodaMachine.GetSodaCash()+"and no less than zero");
                                               choice = input.nextLine().toUpperCase().trim();
                                               CHOICE = TheStorePanel.TryParseDouble(choice);
                                           }
                                           //Withdrawing cash
                                           SodaMachine.AddSodaCash(-CHOICE);
                                           System.out.println("You took "+CHOICE+" and now, the total amount of cash in this vault is "+ SodaMachine.GetSodaCash()+"\n");
                                           break;
                                       }
                                   default:
                                       System.out.println("Please make one of the choices displayed here or press 'Q' to return to previous menu.");
                                       break;
                               }
                           }


                       break; 

               // For case 3 General Machine
                    case "3":
                              while (!choice.equals("Q")) {
                                  System.out.println("The current total cash in this general machine is "+ GeneralMachine.GetGenCash());
                                  System.out.println("Do you want to add an amount to this vault or want to withdraw some amount from it? ");
                                  System.out.println("A. add");
                                  System.out.println("W. withdraw"+"\n");
                                  System.out.println("Q. Go back to the previous menu");
                                  choice = input.nextLine().toUpperCase().trim();
                                  switch (choice) {
                                      case "A":
                                          {
                                              System.out.println("How much do you want to add?");
                                              choice = input.nextLine().toUpperCase().trim();
                                              CHOICE = TheStorePanel.TryParseDouble(choice);
                                              while(CHOICE<0)
                                                {
                                                    System.out.println("To add to your chosen machine, you have to insert an amount greater or equal to zero. Try again!");
                                                    System.out.println("How much do you want to add?");
                                                    choice = input.nextLine().toUpperCase().trim();
                                                    CHOICE = TheStorePanel.TryParseDouble(choice);
                                                }
                                              GeneralMachine.AddGenCash(CHOICE);
                                              System.out.println("You added "+CHOICE+" and now, the total amount of cash in this vault is "+ GeneralMachine.GetGenCash());
                                              break;
                                          }
                                      case "W":
                                          {
                                              System.out.println("How much do you want to withdraw?");
                                              choice = input.nextLine().toUpperCase().trim();
                                              CHOICE = TheStorePanel.TryParseDouble(choice);
                                              while(CHOICE>GeneralMachine.GetGenCash()|| CHOICE<0)
                                              {
                                                  System.out.println("You cannot withdraw an amount greater than what the machine has.");
                                                  System.out.println("Please, insert an amount that is no greater than "+ GeneralMachine.GetGenCash()+" and no lesser than zero.");
                                                  choice = input.nextLine().toUpperCase().trim();
                                                  CHOICE = TheStorePanel.TryParseDouble(choice);
                                              }
                                              GeneralMachine.AddGenCash(-CHOICE);
                                              System.out.println("You took "+CHOICE+" and now, the total amount of cash in this vault is "+ GeneralMachine.GetGenCash()+"\n");
                                              break;
                                          }
                                      default:
                                          System.out.println("Please make one of the choices displayed here or press 'Q' to return to previous menu.");
                                          break;
                                  }
                              }


                          break; 

                    //For the 4th case Total of All of the machines
                    case "4":
                        double TotalCash = CandyMachine.GetCandyCash()+SodaMachine.GetSodaCash()+GeneralMachine.GetGenCash();
                        while (!choice.equals("Q")) {
                               System.out.println("The current total sum of cash of all of the machines is  "+ TotalCash);
                               System.out.println("Do you want to withdraw some amount from it? ");
                               System.out.println("Y. Yes");
                               System.out.println("N. No");
                               choice = input.nextLine().toUpperCase().trim();
                               switch (choice) {
                                   //Withdrawing cash
                                   case "Y":

                                           System.out.println("How much do you want to withdraw?");
                                           choice = input.nextLine().toUpperCase().trim();
                                           CHOICE = TheStorePanel.TryParseDouble(choice);
                                           while(CHOICE>TotalCash)
                                           {
                                               System.out.println("You cannot withdraw an amount greater than what the machines have.");
                                               System.out.println("Please, insert an amount that is no greater than "+ TotalCash);
                                               choice = input.nextLine().toUpperCase().trim();
                                               CHOICE = TheStorePanel.TryParseDouble(choice);
                                           }
                                           TotalCash -= CHOICE;
                                           System.out.println("You took "+CHOICE+" and now, the total amount of cash in this vault is "+ TotalCash+"\n");
                                           break;
                                    //Quiting
                                   case "N":
                                     choice="Q";
                               }
                               //break;
                        }

                      break;
                    default:
                        System.out.println("");
                        break;
                              
                }
                break;
               }
               
            default:
                System.out.println("");
                        break;
        
         
      }
        
        
    }
    
    
}
