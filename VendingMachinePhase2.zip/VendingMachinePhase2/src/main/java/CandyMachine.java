/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author eliasnkuansambu
 */
public final class CandyMachine implements IVendingMachine <Candy> {
    
    protected Queue <Candy> SkittleStack= new LinkedList();
    protected Queue <Candy> SnickerStack= new LinkedList();
    protected Queue <Candy> EmenemStack= new LinkedList();
   // protected Queue <IProduct> SodaStack= new LinkedList();
    
    
    //Controls the cash in the vault
    protected static Double CandyCash;
    protected static Double GetCandyCash(){return CandyCash;}
    public static void SetCandyCash(double val){CandyMachine.CandyCash = val;}
    public static void AddCandyCash(double val ){CandyCash += val;}
    
    //Allows the buyers to insert the quantity of the good they want.
    protected int wantedQuantity;
    protected int GetwantedQuantity(){return wantedQuantity;}
    protected void SetwantedQuantity(int wantedQuantity){this.wantedQuantity = wantedQuantity;}
    
    //To format doubles into the printable text.
    NumberFormat formatter = NumberFormat.getCurrencyInstance();        
            
    Double Price;
    // Constructor of the Machine
    public CandyMachine(double cash) throws CloneNotSupportedException{
        
        //Populating the machine with Skittles
        Candy skittle = new Candy("Skilttle", 4.20);
        for(int i = 1; i<=10; i++){
            SkittleStack.add(skittle.clone());
        }
        
        //Populating the machine with Snickers
        Candy snickers = new Candy("Snickers", 2.42);
        for(int i = 1; i<=10; i++){
            SnickerStack.add(snickers.clone());
        }
     
        //Populating the machine with M&M
        Candy Emenem = new Candy("M&M", 2.40);
        for(int i = 1; i<=10; i++){
            EmenemStack.add(Emenem.clone());
        }
        
        //Cash in the machine
        SetCandyCash(cash);
        
    }
    //Overriding Methods of the interface
    @Override
    public String DisplayContents() {
       //Displaying contents of the candy machine
        System.out.println("You chose a to use a candy machine. Here are your options:");

        System.out.print("A: ");
        CandyExist(SkittleStack);
        System.out.print("\n");
        System.out.print("B: "); 
        CandyExist(SnickerStack);
        System.out.print("\n");
        System.out.print("C: "); 
        CandyExist(EmenemStack);
        System.out.print("\n");
                
        return null;
       
    }
    
    public String CandyExist(Queue <Candy> aa){
        if(aa.size()<=0){
            System.out.println("Item is out of stock.");
        }
        else{
            System.out.print(aa.peek().GetProductName()+" "+"("+aa.size()+") - "+ aa.peek().GetProductPrice()); 
        }
        return null;
    }
    
    
    
    @Override
    public Candy VendItem(String slotCode) {
        // Vending Skittles
        if (slotCode.equals("A") && SkittleStack.size()>0){
            System.out.println("\n"+"Enjoy your " + SkittleStack.peek().GetProductName());
            for(int i = 1; i<=wantedQuantity; i++){SkittleStack.poll();}
        }
        else if(slotCode.equals("A") && wantedQuantity>SkittleStack.size()){System.out.println("The machine only has "+SkittleStack.size() +" skittles. Please make an order that is equal or less than "+SkittleStack.size()+" ." );}
        //Vending Snickers
        if (slotCode.equals("B")&& wantedQuantity<=SnickerStack.size()){
            System.out.println("\n"+"Enjoy your " + SnickerStack.peek().GetProductName());
            for(int i = 1; i<=wantedQuantity; i++){SnickerStack.poll();}
        }
        else if(slotCode.equals("B") && wantedQuantity>SnickerStack.size()){System.out.println("The machine only has "+SnickerStack.size() +" skittles. Please make an order that is equal or less than "+SnickerStack.size()+" ." );}

        //Vending M&Ms
        if (slotCode.equals("C") && wantedQuantity<=EmenemStack.size()){
            System.out.println("\n"+"Enjoy your " + EmenemStack.peek().GetProductName());
            for(int i = 1; i<=wantedQuantity; i++){EmenemStack.poll();}
        }
        else if(slotCode.equals("C") && wantedQuantity>EmenemStack.size()){System.out.println("The machine only has "+EmenemStack.size() +" skittles. Please make an order that is equal or less than "+EmenemStack.size()+" ." );}
        
        
        return null;
    }
    @Override
    public void ReturnMoney(double amount) {
        AddCandyCash(-amount);
        System.out.println("Here is your money "+ amount);
    }
    @Override
    public void TakeMoney(double amount) {
        AddCandyCash(amount);
        System.out.print("\n"+"Thanks for the Payment."+"\n");
        
    }
     @Override
    public String GetMachineInfo() {
       return  DisplayContents();
    }
    //Give change
    public void GiveChange(double amount){
        AddCandyCash(-amount);
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );
        
        
    }
    // Vending stuff method
    public static void VendingStuff(String slotCode, double Price, int Quantity,CandyMachine candymachine, NumberFormat formatter) throws CloneNotSupportedException
    {
        switch (slotCode)
        {
                case "A":
                
                    if (candymachine.SkittleStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    {   Price = candymachine.SkittleStack.peek().GetProductPrice();
                        Quantity = candymachine.SkittleStack.size();
                        TheStorePanel.ProcessingCandy(Price, Quantity, candymachine,formatter,slotCode);
                    }
                    break;
                case "B":
                    if (candymachine.SnickerStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = candymachine.SnickerStack.peek().GetProductPrice();
                        Quantity = candymachine.SnickerStack.size();
                        TheStorePanel.ProcessingCandy(Price, Quantity, candymachine,formatter,slotCode );
                    }
                    break;
                case "C":
                    if (candymachine.EmenemStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = candymachine.EmenemStack.peek().GetProductPrice();
                        Quantity = candymachine.EmenemStack.size();
                        TheStorePanel.ProcessingCandy(Price, Quantity, candymachine,formatter,slotCode );
                    }
                    break;
                case "Q": 
                     System.out.println("");

                     break;
                // Otherwise, get back to displaying the menu  
                default:
                    System.out.println(" You must select a valid choice.");
                    break;

        }
                     
}              
    
  
    
    
}
