/**
 * This is another product in the store machine
 * It is much more complex than the other two types of products.
 */

/**
 *
 * @author eliasnkuansambu
 */
public final class Computer implements IProduct, Cloneable {
    
    //
    // Property of the computer
    //
    
    
    //The memoery of the computer
    protected DiscDrive Disc;// Create a Hard Drive class with distinct characteristics: capacity, cache size, etc
    public DiscDrive getDisc(){return Disc;}
    public void setDisc(DiscDrive val ){Disc=val;}
    
    // Battery of the computer
    protected Battery Battery;
    public Battery getBattery(){return Battery;}
    public void setBattery( Battery val){Battery = val;}
    
    // Screen size in inches
    protected double screen_size;
    public double getScreen_size(){return screen_size;}
    public void setScreen_size(double val){screen_size = val;}
    
    // Brand names: Apple, Asus, Lenovo, Samsung
    protected String BrandName;
    public String GetBrand() { return BrandName; }
    public void SetBrand(String BrandName) { this.BrandName = BrandName; }
    
    // Desktop, portable, screen touch,
    public String kind;
    public String getKind(){return kind;}
    public void setKind(String val){kind = val;}
    
    
    // It is a computer
    private String TypeOfTheProduct = "";
    public String GetProductType() { return TypeOfTheProduct; }
    public void SetProductType(String ProductName) { this.TypeOfTheProduct = ProductName; }

    // Getting the price of the product
    private double Price = 0.00;
    public double GetProductPrice() { return Price; }
    public void SetProductPrice(double ProductPrice) { this.Price = ProductPrice; }
    
    //empty contructor
    public Computer() {}

    // Full constructor
    public Computer(String TypeOfTheProduct, double ProductPrice,String BrandName, String kind, double screen_size,Battery Battery,DiscDrive Disc ) 
    {
        
        SetProductType(TypeOfTheProduct);
        SetProductPrice(ProductPrice);
        SetBrand(BrandName);
        setKind(kind);
        setScreen_size(screen_size);
        setBattery(Battery);
        setDisc(Disc);
        
    }
    
    //
    // Overriding interface Methods
    //
    @Override
    public Computer clone() throws CloneNotSupportedException {
        return (Computer) super.clone();
    }

    @Override
    public String DisplayProductName() {
        
        return GetProductType()+ " "+ GetBrand();
    }

    @Override
    public double DisplayProductPrice() {
        return GetProductPrice();
    }

    
}
