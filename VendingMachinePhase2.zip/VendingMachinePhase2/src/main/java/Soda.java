/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public final class Soda implements IProduct, Cloneable {
    
    //Arraging for brand's name
    protected String Name;
    public String GetName() { return Name; }
    public void SetName(String BrandName) { this.Name = BrandName; }
    
    // Arranging for the price
    private double Price;
    public double GetProductPrice() { return Price; }
    public void SetProductPrice(double val) { this.Price = val; }
    
    // Arranging for the Volume of the soda in mL
    private double volume;
    protected double GetVolume(){return volume;}
    public void SetVolume(double val){volume=val;}
    
    //Flavour
    protected String Flavour;
    public String GetFlavour(){return Flavour;}
    public void SetFlavour(String val){Flavour=val;}
    
    // Empty constructor
    public Soda() {}
    
    //Full constructor 
    public Soda(String BrandName, double Price, String Flavour, double volume) {
        SetName(BrandName);
        SetProductPrice(Price);
        SetFlavour(Flavour);
        SetVolume(volume);
    }
   
    @Override
    public Soda clone() throws CloneNotSupportedException {
        return (Soda) super.clone();
    }

    @Override
    public String DisplayProductName() {
        return GetFlavour()+" "+GetName();
         
    }

    @Override
    public double DisplayProductPrice() {
        return GetProductPrice();
    }
    
}
