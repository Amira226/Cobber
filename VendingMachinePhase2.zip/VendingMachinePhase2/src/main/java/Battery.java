/**
 * Battery class.
 * Created to complement the computer class as an attribute
 * 
 */

/**
 *
 * @author eliasnkuansambu
 */
public final class Battery {
    
    // Capacity in mAh
    public double capacity;
    public double GetBatteryCapacity(){return capacity;}
    public void setBatteryCapcity(double val){capacity=val;}
    
    //Li-ion, Ni-Cad, NiMH
    public String Type;
    public String GetBatteryType(){return Type;}
    public void setBatteryType(String val){Type=val;}
    
    //Empty constructor
    public Battery(){}
    
    //Full constructor
    public Battery(double Capacity,String Type)
        {
            setBatteryCapcity(Capacity);
            setBatteryType(Type);    
            
        }
    
    
}
