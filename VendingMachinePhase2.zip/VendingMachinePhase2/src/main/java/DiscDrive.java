/**
 * This is support class created to help with the properties of the computer class
 *
 */

/**
 *
 * @author eliasnkuansambu
 */
public final class DiscDrive {
    // RAM  Capacity in Gigabytes
    private double RAM_Capacity;
    public double getRAM_Capacity(){return RAM_Capacity;}
    public void setRAM_Capacity(double val){RAM_Capacity=val;}
    
    // ROM Capacity in Gigabytes
    private double ROM_Capacity;
    public double getROM_Capacity(){return ROM_Capacity;}
    public void setROM_Capacity(double val){ROM_Capacity=val;}
    
    //Empty constructor
    public DiscDrive(){}
    
    //Full constructor
    public DiscDrive(double RAM_Capacity, double ROM_Capacity)
    {
        setRAM_Capacity(RAM_Capacity);
        setROM_Capacity(ROM_Capacity);
        
    }
    
}
