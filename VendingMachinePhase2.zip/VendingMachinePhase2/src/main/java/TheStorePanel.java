/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.text.NumberFormat;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author eliasnkuansambu
 */
public class TheStorePanel {
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws CloneNotSupportedException, NumberFormatException {
    
    NumberFormat formatter = NumberFormat.getCurrencyInstance();
    
    // TODO code application logic here
    
    //Building the machines
    CandyMachine candymachine = new CandyMachine(150.00);
    SodaMachine sodamachine = new SodaMachine(100.00);
    GeneralMachine generalmachine = new GeneralMachine(1000.00);
    
    
    //Initiating variables
    
    
    Double Price = 0.00;
    int Quantity = 0;
    //boolean loop = true;
    String userChoice = "";
    
        //Scanner class used in the whole program.
        Scanner in = new Scanner(System.in);
        while(!userChoice.equals("Q")){
            
            //Content to be Displayed
            System.out.println("Please, choose the machine you want to use:");
            System.out.println("1. Candy Vending Machine.");
            System.out.println("2. Soda Vending Machine.");
            System.out.println("3. General Vending Machine.");
            System.out.println("");
            System.out.println("4. Manager Access.");
            System.out.println("Q. Quit");
            
            
            //Collecting user's input
            userChoice = in.nextLine().toUpperCase().trim();

            // Perform user-defined action
            switch (userChoice) {
                case "1":
                    
                    
                    String slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        candymachine.DisplayContents();
                        System.out.println("Q. Go back to the initial screen.");
                        slotCode=in.nextLine().trim().toUpperCase();
                        //Processing the Order
                        CandyMachine.VendingStuff(slotCode, Price, Quantity, candymachine, formatter);
                    }
                    break;
                case "2":

                    slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        sodamachine.DisplayContents();
                        System.out.println("Q. Go back to the initial screen.");
                        slotCode=in.nextLine().trim().toUpperCase();
                        
                        //Processing the Order
                        
                        sodamachine.VendingStuff(slotCode, Price, Quantity, sodamachine, formatter);
                    }                    
                    break;
                case "3":
                    slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        generalmachine.DisplayContents();
                        System.out.println("Q. Go back to the initial screen.");
                        slotCode=in.nextLine().trim().toUpperCase();
                        
                        //Processing the Order
                        
                        GeneralMachine.VendingStuff(slotCode, Price, Quantity, generalmachine, formatter);
                    }
                    
                    break;
                    //Manager's Access
                case "4":
                    slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        System.out.println("Insert 'password' or press 'Q' to go back to the initial screen:");
                        slotCode=in.nextLine().trim().toUpperCase();
                        ManagerAccess.processingManager(slotCode);
                    }
                   break;
    
                case "Q":
                    System.out.println("Thank you for stopping by");
                    System.exit(0);
                default:
                    System.out.println("");
                    break;
            } 
        }
        
    }
    // New Methods
    public static Double TryParseDouble(String A){
        
        try{return Double.parseDouble(A);
        }
        catch(NumberFormatException DN){return 0.00;}
        
    }
    //N
    public static int TryParseInt(String A){
        
        try{return Integer.parseInt(A);
        }
        catch(NumberFormatException DN){return 0;}
        
    }
    
    public static void ProcessingCandy(double Price, int Quantity, CandyMachine candymachine, NumberFormat formatter, String slotCode ) {
        
        Scanner input = new Scanner(System.in);
        // ask for quantity
        System.out.println("Insert Quantity:");
        String bbb = input.nextLine().trim();
        // store it and parse it.                      
        int wantedQuantity = TryParseInt(bbb);
        
        //Addressing errors with the non valid inputs
        while(wantedQuantity==0)
        {
            //The error message
            System.out.println("The value you inserted is not valid."+"\n"+" To be valid, the value has to be a whole number greater than 0. No non-numerical expressions allowed."+"\n"+ " Please try again. Insert a valid quantity:");
            //Get the input
            bbb = input.nextLine().trim();
            // store it and parse it.                      
            wantedQuantity = TryParseInt(bbb);
        }
        String klop = "";
        // Addressing errors with excessive or negative values for quantity
        while (wantedQuantity>Quantity ||Quantity < 0 || wantedQuantity<0 ) 
            {
                System.out.println("It is not possible to give you the quantity of products you desire."+ "\n"+" We only have "+ Quantity +" of the wanted product.");
                System.out.println("Try again."+"\n"+"Please insert the amount you want to purchase:");
                klop = input.nextLine().toUpperCase().trim();
                if(klop.equals("Q")){ break;}
                wantedQuantity = (int)TryParseInt(klop);
            }
         
        if (!klop.equals("Q")){
        // set the wanted quantity
        candymachine.SetwantedQuantity(wantedQuantity);
        // display total cost
        Double Total_Cost = wantedQuantity*Price;
        System.out.println("\n"+"Your total Cost is  "+ formatter.format(Total_Cost) +" .");
        System.out.println("\n"+"Insert your Payment:");
        String aaa= input.nextLine().trim();
        Double PaymentAmount = TryParseDouble(aaa);
        candymachine.TakeMoney(PaymentAmount);
        
        // If payment amount is less than the total cost.
        while(PaymentAmount < Total_Cost)
        {
            System.out.println("\n"+"Insufficient funds. Please insert at least an additional  "+ formatter.format(Total_Cost-PaymentAmount)+" or click 'Q' to quit.");
            String Pay=input.nextLine().trim();
            if(Pay.toUpperCase().equals("Q")){ candymachine.ReturnMoney(PaymentAmount);System.exit(0);}
            else{
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                candymachine.AddCandyCash(PayMore);
            }
        }
        
        //Vend the item
        candymachine.VendItem(slotCode);
        
    // Giving change 
        double Change = PaymentAmount - Total_Cost;
        if (Change>0)
        {
            candymachine.GiveChange(Change);//machine.ReturnMoney(GiveChange);
                                                
        }
        //Final Note...
        System.out.println("\n"+"Thank you for stoping by. Make sure you come back.");
        System.out.println("");
        System.out.println("___________________________________________________________________");
        System.out.println("");
        System.out.println("The machine has "+formatter.format(candymachine.GetCandyCash())+" stored.");
        System.out.println("");
        System.out.println("___________________________________________________________________");
    
        }
    }
    
    
    
    //Processing method for the Soda machine
    public static void ProcessingSoda(double Price, int Quantity, SodaMachine sodamachine, NumberFormat formatter, String slotCode ) {
        
        Scanner input = new Scanner(System.in);
        // ask for quantity
        System.out.println("Insert Quantity:");
        String bbb = input.nextLine().trim();
        // store it and parse it.                      
        int wantedQuantity = TryParseInt(bbb);
        
        //Addressing errors with the non valid inputs
        while(wantedQuantity==0)
        {
            //The error message
            System.out.println("The value you inserted is not valid."+"\n"+" To be valid, the value has to be a whole number greater than 0. No non-numerical expressions allowed."+"\n"+ " Please try again. Insert a valid quantity:");
            //Get the input
            bbb = input.nextLine().trim();
            // store it and parse it.                      
            wantedQuantity = TryParseInt(bbb);
        }
        String klop = "";
        // Addressing errors with excessive or negative values for quantity
        while (wantedQuantity>Quantity ||Quantity < 0 || wantedQuantity<0 ) 
            {
                System.out.println("It is not possible to give you the quantity of products you desire."+ "\n"+" We only have "+ Quantity +" of the wanted product.");
                System.out.println("Try again."+"\n"+"Please insert the amount you want to purchase:");
                klop = input.nextLine().toUpperCase().trim();
                if(klop.equals("Q")){ break;}
                wantedQuantity = (int)TryParseInt(klop);
                
                            
            }
         
        if (!klop.equals("Q")){
        // set the wanted quantity
        sodamachine.SetwantedQuantity(wantedQuantity);
        // display total cost
        Double Total_Cost = wantedQuantity*Price;
        System.out.println("\n"+"Your total Cost is  "+ formatter.format(Total_Cost) +" .");
        System.out.println("\n"+"Insert your Payment:");
        String aaa= input.nextLine().trim();
        Double PaymentAmount = TryParseDouble(aaa);
        sodamachine.TakeMoney(PaymentAmount);
        
        // If payment amount is less than the total cost.
        while(PaymentAmount < Total_Cost)
        {
            System.out.println("\n"+"Insufficient funds. Please insert at least an additional  "+ formatter.format(Total_Cost-PaymentAmount)+" or click 'Q' to quit.");
            String Pay=input.nextLine().trim();
            if(Pay.toUpperCase().equals("Q")){ sodamachine.ReturnMoney(PaymentAmount);System.exit(0);}
            else{
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                sodamachine.AddSodaCash(PayMore);
            }
        }
        
        //Vend the item
        sodamachine.VendItem(slotCode);
        
    // Giving change 
        double Change = PaymentAmount - Total_Cost;
        if (Change>0)
        {
            sodamachine.GiveChange(Change);//machine.ReturnMoney(GiveChange);
                                                
        }
        //Final Note...
        System.out.println("\n"+"Thank you for stoping by. Make sure you come back.");
        System.out.println("");
        System.out.println("___________________________________________________________________");
        System.out.println("");
        System.out.println("The Soda machine has "+formatter.format(sodamachine.GetSodaCash())+" stored.");
        System.out.println("");
        System.out.println("___________________________________________________________________");
    
        }
    }
    
    
    
    //
    //Processing method for the General machine
    //
    public static void ProcessingGeneral(double Price, int Quantity, GeneralMachine generalmachine, NumberFormat formatter, String slotCode ) {
        
        Scanner input = new Scanner(System.in);
        // ask for quantity
        System.out.println("Insert Quantity:");
        String bbb = input.nextLine().trim();
        // store it and parse it.                      
        int wantedQuantity = TryParseInt(bbb);
        
        //Addressing errors with the non valid inputs
        while(wantedQuantity==0)
        {
            //The error message
            System.out.println("The value you inserted is not valid."+"\n"+" To be valid, the value has to be a whole number greater than 0. No non-numerical expressions allowed."+"\n"+ " Please try again. Insert a valid quantity:");
            //Get the input
            bbb = input.nextLine().trim();
            // store it and parse it.                      
            wantedQuantity = TryParseInt(bbb);
        }
        String klop = "";
        // Addressing errors with excessive or negative values for quantity
        while (wantedQuantity>Quantity ||Quantity < 0 || wantedQuantity<0 ) 
            {
                System.out.println("It is not possible to give you the quantity of products you desire."+ "\n"+" We only have "+ Quantity +" of the wanted product.");
                System.out.println("Try again."+"\n"+"Please insert the amount you want to purchase:");
                klop = input.nextLine().toUpperCase().trim();
                if(klop.equals("Q")){ break;}
                wantedQuantity = (int)TryParseInt(klop);
                
                            
            }
         
        if (!klop.equals("Q")){
        // set the wanted quantity
        generalmachine.SetwantedQuantity(wantedQuantity);
        // display total cost
        Double Total_Cost = wantedQuantity*Price;
        System.out.println("\n"+"Your total Cost is  "+ formatter.format(Total_Cost) +" .");
        System.out.println("\n"+"Insert your Payment:");
        String aaa= input.nextLine().trim();
        Double PaymentAmount = TryParseDouble(aaa);
        generalmachine.TakeMoney(PaymentAmount);
        
        // If payment amount is less than the total cost.
        while(PaymentAmount < Total_Cost)
        {
            System.out.println("\n"+"Insufficient funds. Please insert at least an additional  "+ formatter.format(Total_Cost-PaymentAmount)+" or click 'Q' to quit.");
            String Pay=input.nextLine().trim();
            if(Pay.toUpperCase().equals("Q")){ generalmachine.ReturnMoney(PaymentAmount);System.exit(0);}
            else{
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                generalmachine.AddGenCash(PayMore);
            }
        }
        
        //Vend the item
        generalmachine.VendItem(slotCode);
        
    // Giving change 
        double Change = PaymentAmount - Total_Cost;
        if (Change>0)
        {
            generalmachine.GiveChange(Change);//machine.ReturnMoney(GiveChange);
                                                
        }
        //Final Note...
        System.out.println("\n"+"Thank you for stoping by. Make sure you come back.");
        System.out.println("");
        System.out.println("___________________________________________________________________");
        System.out.println("");
        System.out.println("The Soda machine has "+formatter.format(generalmachine.GetGenCash())+" stored.");
        System.out.println("");
        System.out.println("___________________________________________________________________");
    
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

/**
 * 
 * 
 * 
 * 
 *    
                       
                        
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    /**
                     * while(q!){ Present the options}
                     * Continues to happen as long as none of the option including Q is not chosen. 
                     * display content of the machine.
                     * Ask for the slotCode
                     * Depending on the slotCode, take the price and available quantity of the stack.
                     * insert wantedQuantity
                     * Check if wantedQuantity is less or equal to Quantity.
                     *  If above is false, show error and return to the machine menu
                     *  if above is true, proceed with code...
                     * Take total cost == price *wantedQuantity.
                     * Print total cost
                     * Insert Payment
                     * Check payment:
                     *  if it is not valid... ask it again and again or press Q to quit.
                     *  if it valid... proceed 
                     * if 
                     * 
                     * 
                     * 
                     * 
                     * 
                     * if it is out of stock, print it.
                     * 
                     * 
                     * 
                     * 
                     * 
                     * 
                     * 
                     * 
                     */
 



