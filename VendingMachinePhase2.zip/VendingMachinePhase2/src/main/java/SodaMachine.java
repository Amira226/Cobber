
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public final class SodaMachine implements IVendingMachine <Soda>{
    
    // Stacks of the different Kinds of sodas
    protected Queue <Soda> CocaColaStack= new LinkedList();
    protected Queue <Soda> PepsiStack= new LinkedList();
    protected Queue <Soda> DrPepperStack= new LinkedList();
    protected Queue <Soda> CocaColaFlavouredStack= new LinkedList();
    protected Queue <Soda> PepsiFlavouredStack= new LinkedList();
    protected Queue <Soda> DrPepperFlavouredStack= new LinkedList();

    
    
    //Controls the cash in the vault of the soda vending machine
    protected static Double SodaCash;
    public static Double GetSodaCash(){return SodaCash;}
    public static void SetSodaCash(double val){SodaMachine.SodaCash = val;}
    public static void AddSodaCash(double val ){SodaCash += val;}
    
    //Allows the buyers to insert the quantity of the good they want.
    protected int wantedQuantity;
    protected int GetwantedQuantity(){return wantedQuantity;}
    public void SetwantedQuantity(int wantedQuantity){this.wantedQuantity = wantedQuantity;}
    
    //To format doubles into the printable text.
    NumberFormat formatter = NumberFormat.getCurrencyInstance();        

            
    Double Price;
    
    // Constructor of the Machine
    public SodaMachine(double cash) throws CloneNotSupportedException{
        
        //Instatianting the sodas
        Soda CocaCola = new Soda("Coke", 4.20,"Original", 330);
        Soda Pepsi = new Soda("Pepsi", 4.10,"Original", 330);
        Soda DrPepper = new Soda("DrPepper", 2.40,"Original",330);
        
        //Flavoured sodas
        Soda CocaColaFlavoured = new Soda("Coke", 4.20,"Cherry", 330);
        Soda PepsiFlavoured = new Soda("Pepsi", 4.10,"Diet", 330);
        Soda DrPepperFlavoured = new Soda("DrPepper", 3.40,"cherry vannila",330);
        
        //Populating the machine
        for(int i = 1; i<=11; i++){
            
            //Flavoured and unflavored Coke
            CocaColaStack.add(CocaCola.clone());
            CocaColaFlavouredStack.add(CocaColaFlavoured.clone());
            
            //Flavoured and unflavored Pepsi
            PepsiStack.add(Pepsi.clone());
            PepsiFlavouredStack.add(PepsiFlavoured.clone());
            
            //Flavoured and unflavored DrPepper
            DrPepperStack.add(DrPepper.clone());
            DrPepperFlavouredStack.add(DrPepperFlavoured.clone());
        }
        
        //Cash in the machine
        SetSodaCash(cash);
    }
    
    
    //
    //OVERRIDING METHODS
    //
    @Override
    public void TakeMoney(double amount) {
        AddSodaCash(amount);
        System.out.print("\n"+"Thanks for the Payment."+"\n");
        
    }

    @Override
    public void ReturnMoney(double amount) {
        
        AddSodaCash(-amount);
        System.out.println("Here is your money "+ amount);
        
    }

    @Override
    public Soda VendItem(String slotCode) {
        
        // Vending Cokes
        if (slotCode.equals("A") && CocaColaStack.size()>0){
            System.out.println("\n"+"Enjoy your " + CocaColaStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){CocaColaStack.poll();}
        }
        else if(slotCode.equals("A") && wantedQuantity>CocaColaStack.size()){System.out.println("The machine only has "+CocaColaStack.size() +" "+CocaColaStack.peek().DisplayProductName() +"s . Please make an order that is equal or less than "+CocaColaStack.size()+" ." );}
        
        //Vending Pepsi
        if (slotCode.equals("B")&& wantedQuantity<=PepsiStack.size()){
            System.out.println("\n"+"Enjoy your " + PepsiStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){PepsiStack.poll();}
        }
        else if(slotCode.equals("B") && wantedQuantity>PepsiStack.size()){System.out.println("The machine only has "+PepsiStack.size() +" "+PepsiStack.peek().DisplayProductName()  + "s . Please make an order that is equal or less than "+PepsiStack.size()+" ." );}

        //Vending DrPepper
        if (slotCode.equals("C") && wantedQuantity<=DrPepperStack.size()){
            System.out.println("\n"+"Enjoy your " + DrPepperStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){DrPepperStack.poll();}
        }
        else if(slotCode.equals("C") && wantedQuantity>DrPepperStack.size()){System.out.println("The machine only has "+DrPepperStack.size() + " "+DrPepperStack.peek().DisplayProductName() +"s . Please make an order that is equal or less than "+DrPepperStack.size()+" ." );}

        
        //Vending Flavoured Coke
        if (slotCode.equals("D") && wantedQuantity<=CocaColaFlavouredStack.size()){
            System.out.println("\n"+"Enjoy your " + CocaColaFlavouredStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){CocaColaFlavouredStack.poll();}
        }
        else if(slotCode.equals("D") && wantedQuantity>CocaColaFlavouredStack.size()){System.out.println("The machine only has "+CocaColaFlavouredStack.size() +" "+CocaColaFlavouredStack.peek().DisplayProductName() +"s . Please make an order that is equal or less than "+CocaColaFlavouredStack.size()+" ." );}
        
        //Vending Flavoured Pepsi
        if (slotCode.equals("E") && wantedQuantity<=PepsiFlavouredStack.size()){
            System.out.println("\n"+"Enjoy your " + PepsiFlavouredStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){PepsiFlavouredStack.poll();}
        }
        else if(slotCode.equals("E") && wantedQuantity>PepsiFlavouredStack.size()){System.out.println("The machine only has "+PepsiFlavouredStack.size() +" "+PepsiFlavouredStack.peek().DisplayProductName() +"s . Please make an order that is equal or less than "+PepsiFlavouredStack.size()+" ." );}

        //Vending Flavoured DrPepper
        if (slotCode.equals("F") && wantedQuantity<=DrPepperFlavouredStack.size()){
            System.out.println("\n"+"Enjoy your " + DrPepperFlavouredStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){DrPepperFlavouredStack.poll();}
        }
        else if(slotCode.equals("F") && wantedQuantity>DrPepperFlavouredStack.size()){System.out.println("The machine only has "+DrPepperFlavouredStack.size() +" "+DrPepperFlavouredStack.peek().DisplayProductName() +" . Please make an order that is equal or less than "+DrPepperFlavouredStack.size()+" ." );}

        
        return null;
        
        
        
    }

    @Override
    public String GetMachineInfo() {
        System.out.println("This Machine is a Soda machine. Thus, it sells only different varieties of sodas.");
        DisplayContents();
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    //This method shows the menu for the soda machine, listing all the types of sodas it has
    @Override
    public String DisplayContents() {
        
        System.out.print("\n");
        System.out.print("\n");
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        
        System.out.print("A: ");
        SodaExist(CocaColaStack);
        System.out.print("\n");
        System.out.print("B: "); 
        SodaExist(PepsiStack);
        System.out.print("\n");
        System.out.print("C: "); 
        SodaExist(DrPepperStack);
        System.out.print("\n");
        
        System.out.println("_____________________________________________________");
        System.out.println("Flavoured sodas:");
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        
        System.out.print("D: "); 
        SodaExist(CocaColaFlavouredStack);
        System.out.print("\n");
        System.out.print("E: "); 
        SodaExist(PepsiFlavouredStack);
        System.out.print("\n");
        System.out.print("F: "); 
        SodaExist(DrPepperFlavouredStack);
        System.out.print("\n");
        System.out.println("_____________________________________________________");

        
        return null;
        
    }

    public String SodaExist(Queue <Soda> aa){
        if(aa.size()<=0){
            System.out.println("Item is out of stock.");
        }
        else{
            System.out.print(aa.peek().DisplayProductName()+" "+"("+aa.size()+") - "+ aa.peek().DisplayProductPrice()); 
        }
        return null;
    }
    
    public void GiveChange(double amount){
        AddSodaCash(-amount);
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );
    }
    
    //Vending Operations
    public void VendingStuff(String slotCode, double Price, int Quantity,SodaMachine Sodamachine, NumberFormat formatter)
    {
        //This switch case accounts for all of the options and their respectives outcomes
        switch (slotCode)
        {
                case "A":
                
                    if (Sodamachine.CocaColaStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    {   Price = Sodamachine.CocaColaStack.peek().GetProductPrice();
                        Quantity = Sodamachine.CocaColaStack.size();
                        TheStorePanel.ProcessingSoda(Price, Quantity, Sodamachine, formatter, slotCode);
        
                    }
                    break;
                case "B":
                    if (Sodamachine.PepsiStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = Sodamachine.PepsiStack.peek().GetProductPrice();
                        Quantity = Sodamachine.PepsiStack.size();
                        TheStorePanel.ProcessingSoda(Price, Quantity, Sodamachine,formatter,slotCode );
                    }
                    break;
                case "C":
                    if (Sodamachine.DrPepperStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = Sodamachine.DrPepperStack.peek().GetProductPrice();
                        Quantity = Sodamachine.DrPepperStack.size();
                        TheStorePanel.ProcessingSoda(Price, Quantity, Sodamachine,formatter,slotCode );
                    }
                    break;
                case "D":
                    if (Sodamachine.CocaColaFlavouredStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = Sodamachine.CocaColaFlavouredStack.peek().GetProductPrice();
                        Quantity = Sodamachine.CocaColaFlavouredStack.size();
                        TheStorePanel.ProcessingSoda(Price, Quantity, Sodamachine,formatter,slotCode );
                    }
                    break;
                case "E":
                    if (Sodamachine.PepsiFlavouredStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = Sodamachine.PepsiFlavouredStack.peek().GetProductPrice();
                        Quantity = Sodamachine.PepsiFlavouredStack.size();
                        TheStorePanel.ProcessingSoda(Price, Quantity, Sodamachine,formatter,slotCode );
                    }
                    break;
                case "F":
                    if (Sodamachine.DrPepperFlavouredStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = Sodamachine.DrPepperFlavouredStack.peek().GetProductPrice();
                        Quantity = Sodamachine.DrPepperFlavouredStack.size();
                        TheStorePanel.ProcessingSoda(Price, Quantity, Sodamachine,formatter,slotCode );
                    }
                    break;
                case "Q": 
                     System.out.println("");

                     break;
                // Otherwise, get back to displaying the menu  
                default:
                    System.out.println(" You must select a valid choice.");
                    break;

        }
                     
    }
   
    
}
