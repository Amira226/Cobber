
/*
 * This is an Interface already given by the professor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public interface IVendingMachine <E> {
    
    // Accepts the amount of money from user
    void TakeMoney (double amount);
    // Returns the amount of money to user
    void ReturnMoney (double amount);
    // Spits out an item based on the vending slot chosen by user
    // Each vending machine should have SlotA , SlotB , and SlotC
    // Up to 5 items can be placed in each slot of the vending machine
    E VendItem (String slotCode );
    // Displays what kind of vending machine it is
    String GetMachineInfo ();
    // Shows the item name and price for each Slot of machine
    String DisplayContents ();

    
    
}
