
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public class GeneralMachine implements IVendingMachine <IProduct>{

//    // Making the stack of products available in this general machine
    protected Queue <IProduct> AppleComputerStack =new LinkedList();
    protected Queue <IProduct> DellComputerStack =new LinkedList();
    protected Queue <IProduct> SamsungComputerStack =new LinkedList();
    protected Queue <IProduct> CocaColaStack= new LinkedList();
    protected Queue <IProduct> EmenemStack= new LinkedList();
    protected Queue <IProduct> DrPepperFlavouredStack= new LinkedList();
    protected Queue <IProduct> SkittleStack= new LinkedList();
    protected Queue <IProduct> MixedStack= new LinkedList();
    
    
    //Controls the cash in the vault of the soda vending machine
    protected static Double GenCash;
    public static Double GetGenCash(){return GenCash;}
    public static  void SetGenCash(double val){GeneralMachine.GenCash = val;}
    public static void AddGenCash(double val ){GenCash += val;}
    
    //Allows the buyers to insert the quantity of the good they want.
    protected int wantedQuantity;
    protected int GetwantedQuantity(){return wantedQuantity;}
    public void SetwantedQuantity(int wantedQuantity){this.wantedQuantity = wantedQuantity;}
    
    //To format doubles into the printable text.
    NumberFormat formatter = NumberFormat.getCurrencyInstance();        

            
    Double Price;
    
    // Constructor of the Machine
    public GeneralMachine(double cash) throws CloneNotSupportedException{
        
        //instatiating the Products
        Soda CocaCola = new Soda("Coke", 4.20,"Original", 330);
        Computer Macbook = new Computer("Computer",937.99,"Apple", "laptop", 14.7, new Battery(5020.00,"Li-Ion"),new DiscDrive(2.00,120.00));
        Computer Dell = new Computer("Computer",699.99,"Dell", "Desktop", 19.0, new Battery(3800.00,"NiH"),new DiscDrive(3.00,920.00));
        Computer Samsung = new Computer("Computer",599.99,"Samsung", "Digital", 13.0, new Battery(1800.00,"NiH"),new DiscDrive(3.00,220.00));
        Candy skittle = new Candy("Skilttle", 4.20);
        Candy Emenem = new Candy("M&M", 2.40);
        Soda DrPepperFlavoured = new Soda("DrPepper", 3.40,"cherry vannila",330);
        //multiplying the products in the machine
        for(int i = 1; i<=10; i++){
            CocaColaStack.add(CocaCola.clone());
            SkittleStack.add(skittle.clone());
            AppleComputerStack.add(Macbook.clone());
            DellComputerStack.add(Dell.clone());
            SamsungComputerStack.add(Samsung.clone());
            EmenemStack.add(Emenem.clone());
            DrPepperFlavouredStack.add(DrPepperFlavoured.clone());
            
        }
        //setting the cash
        SetGenCash(cash);
        
    }
    
    //----------------------------------------
    // Overriding Methods
    //----------------------------------------
    @Override
    public void TakeMoney(double amount) {
        AddGenCash(amount);
        System.out.print("\n"+"Thanks for the Payment."+"\n");
    }

    @Override
    public void ReturnMoney(double amount) {
        AddGenCash(-amount);
        System.out.println("Here is your money "+ amount);
 
    }

    @Override
    public IProduct VendItem(String slotCode) {
        
        //Vending coke
        if (slotCode.equals("A") && CocaColaStack.size()>0){
            System.out.println("\n"+"Enjoy your " + CocaColaStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){CocaColaStack.poll();}
        }
        else if(slotCode.equals("A") && wantedQuantity>CocaColaStack.size()){System.out.println("The machine only has "+CocaColaStack.size() +""+CocaColaStack.peek().DisplayProductName() +" . Please make an order that is equal or less than "+CocaColaStack.size()+" ." );}
        
        //Vending DrPepper
        if (slotCode.equals("B")&& wantedQuantity<=DrPepperFlavouredStack.size()){
            System.out.println("\n"+"Enjoy your " + DrPepperFlavouredStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){DrPepperFlavouredStack.poll();}
        }
        else if(slotCode.equals("B") && wantedQuantity>DrPepperFlavouredStack.size()){System.out.println("The machine only has "+DrPepperFlavouredStack.size() +""+ DrPepperFlavouredStack.peek().DisplayProductName()+ " . Please make an order that is equal or less than "+DrPepperFlavouredStack.size()+" ." );}

        //Vending M&M
        if (slotCode.equals("C") && wantedQuantity<=EmenemStack.size()){
            System.out.println("\n"+"Enjoy your " + EmenemStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){EmenemStack.poll();}
        }
        else if(slotCode.equals("C") && wantedQuantity>EmenemStack.size()){System.out.println("The machine only has "+EmenemStack.size() +""+ EmenemStack.peek().DisplayProductName() +". Please make an order that is equal or less than "+EmenemStack.size()+" ." );}

        
        //Vending Skittles
        if (slotCode.equals("D") && wantedQuantity<=SkittleStack.size()){
            System.out.println("\n"+"Enjoy your " + SkittleStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){SkittleStack.poll();}
        }
        else if(slotCode.equals("D") && wantedQuantity>SkittleStack.size()){System.out.println("The machine only has "+SkittleStack.size() +""+ SkittleStack.peek().DisplayProductName()+ ". Please make an order that is equal or less than "+SkittleStack.size()+" ." );}
        
        //Vending Macbook
        if (slotCode.equals("E") && wantedQuantity<=AppleComputerStack.size()){
            System.out.println("\n"+"Enjoy your " + AppleComputerStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){AppleComputerStack.poll();}
        }
        else if(slotCode.equals("E") && wantedQuantity>AppleComputerStack.size()){System.out.println("The machine only has "+AppleComputerStack.size() +""+AppleComputerStack.peek().DisplayProductName()+ ". Please make an order that is equal or less than "+AppleComputerStack.size()+" ." );}

        //Vending Dell Computers
        if (slotCode.equals("F") && wantedQuantity<=DellComputerStack.size()){
            System.out.println("\n"+"Enjoy your " + DellComputerStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){DellComputerStack.poll();}
        }
        else if(slotCode.equals("F") && wantedQuantity>DellComputerStack.size()){System.out.println("The machine only has "+DellComputerStack.size() +""+ DellComputerStack.peek().DisplayProductName()+ ". Please make an order that is equal or less than "+DellComputerStack.size()+" ." );}
        
        //Vending Dell Computers
        if (slotCode.equals("G") && wantedQuantity<=SamsungComputerStack.size()){
            System.out.println("\n"+"Enjoy your " + SamsungComputerStack.peek().DisplayProductName());
            for(int i = 1; i<=wantedQuantity; i++){SamsungComputerStack.poll();}
        }
        else if(slotCode.equals("G") && wantedQuantity>SamsungComputerStack.size()){System.out.println("The machine only has "+SamsungComputerStack.size() +""+ SamsungComputerStack.peek().DisplayProductName()+ ". Please make an order that is equal or less than "+SamsungComputerStack.size()+" ." );}
        
        return null;
       
    }

    @Override
    public String GetMachineInfo() {
        System.out.println("This Machine is a general machine. Thus, it sells all kinds of products available in the store.");
        DisplayContents();
        return null;
    }

    @Override
    public String DisplayContents() {
        
        System.out.println("_____________________________________________________");
        System.out.print("\n");
//        System.out.print("Thanks for choose this our store. Here is our menu:");
//        System.out.println("_____________________________________________________");
//        System.out.print("\n");
        
        
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        System.out.println("Listing the sodas:");
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        
        //list the sodas
        System.out.print("A: ");
        ProductExist(CocaColaStack);
        System.out.print("\n");
        System.out.print("B: "); 
        ProductExist(DrPepperFlavouredStack);
        System.out.print("\n");
        
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        System.out.println("Listing the candies:");
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        
        //Listing the candies
        System.out.print("C: "); 
        ProductExist(EmenemStack);
        System.out.print("\n");
        System.out.print("D: "); 
        ProductExist(SkittleStack);
        System.out.print("\n");
        
        
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        System.out.println("Listing the computers:");
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        
        //Listing the computers
        System.out.print("E: "); 
        ProductExist(AppleComputerStack);
        System.out.print("\n");
        System.out.print("F: "); 
        ProductExist(DellComputerStack);
        System.out.print("\n");
        System.out.print("G: "); 
        ProductExist(SamsungComputerStack);
        System.out.print("\n");
        System.out.println("_____________________________________________________");
        System.out.print("\n");
        return null;
        
    }
    
    //Checking if the product exits
    public String ProductExist(Queue <IProduct> aa){
        if(aa.size()<=0){
            System.out.println("Item is out of stock.");
        }
        else{
            System.out.print(aa.peek().DisplayProductName()+" "+"("+aa.size()+") - "+ aa.peek().DisplayProductPrice()); 
        }
        return null;
    }
    //Giving change
    public void GiveChange(double amount){
        AddGenCash(-amount);
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );
        
        
    }
    
        //Vending Operations
    public static void VendingStuff(String slotCode, double Price, int Quantity, GeneralMachine generalmachine, NumberFormat formatter)
    {
        //Using swtich case statements to program the choices
        switch (slotCode)
        {
                case "A":
                
                    if (generalmachine.CocaColaStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    {   Price = generalmachine.CocaColaStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.CocaColaStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode);
                    }
                    break;
                case "B":
                    if (generalmachine.DrPepperFlavouredStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = generalmachine.DrPepperFlavouredStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.DrPepperFlavouredStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode );
                    }
                    break;
                case "C":
                    if (generalmachine.EmenemStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = generalmachine.EmenemStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.EmenemStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode );
                    }
                    break;
                case "D":
                    if (generalmachine.SkittleStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = generalmachine.SkittleStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.SkittleStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode );
                    }
                    break;
                case "E":
                    if (generalmachine.AppleComputerStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = generalmachine.AppleComputerStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.AppleComputerStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode );
                    }
                    break;
                case "F":
                    if (generalmachine.DellComputerStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = generalmachine.DellComputerStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.DellComputerStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode );
                    }
                    break;
                case "G":
                    if (generalmachine.SamsungComputerStack.isEmpty()){System.out.println("The Item you chose is out of stock. Choose something else.");}
                    else
                    { 
                        Price = generalmachine.SamsungComputerStack.peek().DisplayProductPrice();
                        Quantity = generalmachine.SamsungComputerStack.size();
                        TheStorePanel.ProcessingGeneral(Price, Quantity, generalmachine,formatter,slotCode );
                    }
                    break;
                    
                case "Q": 
                     System.out.println("");

                     break;
                // Otherwise, get back to displaying the menu  
                default:
                    System.out.println(" You must select a valid choice.");
                    break;

        }
                     
}
    
    
    
    
    
    
    
}
