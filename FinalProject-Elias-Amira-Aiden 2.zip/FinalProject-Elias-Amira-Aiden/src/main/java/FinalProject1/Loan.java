/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProject1;


/**
 * The purpose of this class is to create the formulas and setting up the constructors and the methods for the formula.
 * @author eliasnkuansambu
 */
public class Loan {
    
    //instance variables
    private double loanAmount;
    private double monthly_Paymemts;
    private double interestRate;
    public double loanTerm;
    
    // constructor of the loan object
    public Loan (double loanAmount1, double interestRate1, double loanTerm1 )
    {
        loanAmount = loanAmount1;
        interestRate = interestRate1/12.0;
        loanTerm = loanTerm1*12.0;
        monthly_Paymemts = monthly_Paymemts;
       }
// Formula to get the monthly payments
    public double getPaymentsPerMonth() {

        
        monthly_Paymemts =loanAmount*(interestRate*(Math.pow((1+interestRate),loanTerm))/((Math.pow((1+interestRate),loanTerm))-1));
        return monthly_Paymemts;
    }
        
       
 /* 
//It needs futher coding to be useful to this program.    
//It calculates the loan term
    public double getLoanTerm() {

        loanTerm = - (Math.log10(1-interestRate*(monthly_Paymemts/loanAmount)))/(Math.log10(1+interestRate)); // in need of rounding to an integer number.
        return loanTerm;
    }

   */ 
    
    
}
