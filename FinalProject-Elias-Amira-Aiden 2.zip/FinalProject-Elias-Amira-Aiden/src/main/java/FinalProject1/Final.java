package FinalProject1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.text.DecimalFormat;
import java.awt.Color;

/**
 * The purpose of this class is to create the JFrames and collected data from the text fields. 
 * @author eliasnkuansambu
 */
public class Final
{
// instanciate the variables 
    private static JLabel interestRateLable;
    private static JTextField interestRateTextField;
    private static JLabel loanAmmountLable;
    public static JTextField loanAmmountTextField;
    private static JLabel loanTermLable;
    private static JTextField loanTermTextField;
    
    Final() {
        // TODO code application logic here
        
        System.out.println("Testing");
        
        JFrame f = new JFrame ("Loan Calculator"); //creating a new JFrame for our Calculator
        f.setSize(600,600);    
        f.setLayout(null);    
        f.setVisible(true);    
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
//        
//        JPanel p = new JPanel();
//        p.setBackground(Color.RED);
        
        //submit button
        JButton b=new JButton("Submit");    //button that will run the program 
        b.setBounds(400 ,500 ,140, 40);    
                    
        JLabel warningLable =new JLabel(); //Warning label about what values are accepted
        warningLable.setText("Please ONLY enter positive numbers! And interest rate should always between 0 and 1");
        warningLable.setBounds(10, 10, 550, 30);
        
        JLabel loanAmmountLable = new JLabel();    //loan Amount description
        loanAmmountLable.setText("Loan Amount");
        loanAmmountLable.setBounds(10, 10, 250, 100);
        JTextField loanAmmountTextField= new JTextField(); //area to enter information
        loanAmmountTextField.setBounds(250, 45, 130, 30);
        
        JLabel interestRateLable = new JLabel();  
        interestRateLable.setText("Interest Rate (annual value)");
        interestRateLable.setBounds(10, 10, 250, 150);
        JTextField interestRateTextField= new JTextField();
        interestRateTextField.setBounds(250, 70, 130, 30); 
        
        JLabel loanTermLable = new JLabel();  
        loanTermLable.setText("Loan Term (in years)");
        loanTermLable.setBounds(10, 10, 250, 200);
        JTextField loanTermTextField= new JTextField();
        loanTermTextField.setBounds(250, 95, 130, 30); 
        
        JLabel label1 = new JLabel();
        label1.setBounds(10, 130, 400, 250); 
        
        
//add to frame
        f.add(label1);
        f.add(loanAmmountTextField);
        f.add(loanAmmountLable);
        f.add(interestRateLable);
        f.add(interestRateTextField);
        f.add(loanTermLable);
        f.add(loanTermTextField);
        f.add(warningLable);
        f.add(b);
        
//        f.add(p);
       
//        f.add(p);
        //action listener
        b.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent arg0) {
               //access the text fileds for informaiton
                String loanText = loanAmmountTextField.getText();
                String interestText = interestRateTextField.getText();
                String loanTermText = loanTermTextField.getText();
             

                //Converting the text into numbers
                double loanAmount = Double.parseDouble(loanText);
                double interestRate = Double.parseDouble(interestText);
                double loanTerm = Double.parseDouble(loanTermText);
                              
               
               //instantiate a Loan object, using information from the text fields
               Loan currentLoan = new Loan(loanAmount,interestRate,loanTerm);    //Double.parseDouble(loanAmmountTextField.getText()), Double.parseDouble(interestRateTextField.getText()), Double.parseDouble(loanTermTextField.getText()));
               double minPayment = currentLoan.getPaymentsPerMonth();
               
               //Convert the rsult into number and edit it.
               DecimalFormat y = new DecimalFormat("#.##");
               minPayment = Double.valueOf(y.format(minPayment));
               
               //call the methods on the loan object to get the loan payments
               //print that stuff out!
               
               
               //double thingToPrint = minPayment;
               label1.setText("");
               label1.setText("Minimum monthly payment of is :" + minPayment);
    }
   
        });
}
    public static void main(String[] args) {
        new Final();
        
       
    }
    
}
