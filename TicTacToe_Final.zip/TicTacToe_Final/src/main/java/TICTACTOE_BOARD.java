
import javax.swing.JOptionPane;

/**
 *
 * @author Oriana
 */

//First of all I went to the desing window and made the board and added the buttons, changed the font and also added some of my favorite colors
public class TICTACTOE_BOARD extends javax.swing.JFrame {

    /**
     * Creates new form TICTACTOE_BOARD
     */
    public TICTACTOE_BOARD() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tic Tac Toe");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setFont(new java.awt.Font("Curlz MT", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 0, 255));
        jLabel1.setText("                 Tic Tac Toe");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 669, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton1.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 102, 255));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 102, 255));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 102, 255));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 102, 255));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 102, 255));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 102, 255));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 102, 255));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 102, 255));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 102, 255));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        resetButton.setBackground(new java.awt.Color(255, 204, 255));
        resetButton.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 36)); // NOI18N
        resetButton.setText("Reset");
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(66, 317, Short.MAX_VALUE)
                        .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    int PlayerTurn =1;
    //From here below you can see all the nine buttons which the user can click to choose the spot where they want their symbols to be
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
       if (jButton1.getText()==""){ //This if statement that repeats itself through each of the buttons basically stablishes that when the buttons are click the symbols will appear on the sreen
           if (PlayerTurn==1){
               jButton1.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton1.setText ("X");
               PlayerTurn = 1;     
           }
       }
       WinnerOfTheGame (); //This is to show who won the game if X or O
       Tie (); //This is to show if the game ended up as a draw
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
         if (jButton4.getText()==""){
           if (PlayerTurn==1){
               jButton4.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton4.setText ("X");
               PlayerTurn = 1;     
           }
       }
         WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
         if (jButton6.getText()==""){
           if (PlayerTurn==1){
               jButton6.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton6.setText ("X");
               PlayerTurn = 1;     
           }
       }
         WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
         if (jButton10.getText()==""){
           if (PlayerTurn==1){
               jButton10.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton10.setText ("X");
               PlayerTurn = 1;     
           }
       }
         WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
         if (jButton3.getText()==""){
           if (PlayerTurn==1){
               jButton3.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton3.setText ("X");
               PlayerTurn = 1;     
           }
       }
         WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
       if (jButton5.getText()==""){
           if (PlayerTurn==1){
               jButton5.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton5.setText ("X");
               PlayerTurn = 1;     
           }
       }
       WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
         if (jButton7.getText()==""){
           if (PlayerTurn==1){
               jButton7.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton7.setText ("X");
               PlayerTurn = 1;     
           }
       }
       WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
         if (jButton8.getText()==""){
           if (PlayerTurn==1){
               jButton8.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton8.setText ("X");
               PlayerTurn = 1;     
           }
       }
         WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
         if (jButton9.getText()==""){
           if (PlayerTurn==1){
               jButton9.setText ("O");
               PlayerTurn = 2;
           }
           else if(PlayerTurn==2){
               jButton9.setText ("X");
               PlayerTurn = 1;     
           }
       }
       WinnerOfTheGame ();
       Tie ();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        // TODO add your handling code here:
        //This is the reset button that when is clicked will clear all of the other buttons
        jButton1.setText("");
        jButton3.setText("");
        jButton4.setText("");
        jButton5.setText("");
        jButton6.setText("");
        jButton7.setText("");
        jButton8.setText("");
        jButton9.setText("");
        jButton10.setText("");
        
        
    }//GEN-LAST:event_resetButtonActionPerformed
    //Winner!
    
    public void WinnerOfTheGame (){ ////It allows the user to know who won the game X or O
    
    
    String one = jButton1.getText (); //I am sorry if the numbering looks a bit messy, but dont worry this are the correct positions of each buttons
    String two = jButton3.getText ();
    String three = jButton4.getText ();
    String four = jButton5.getText ();
    String five = jButton7.getText ();
    String six = jButton6.getText ();
    String seven = jButton8.getText ();
    String eight = jButton9.getText ();
    String nine = jButton10.getText ();
    
     
    if (one.equals ("X") && two.equals ("X") && three.equals ("X")){  //All of these are basically the different winning combinations that X can have
     WinnerIsX ();  
    }
    if (four.equals ("X") && five.equals ("X") && six.equals ("X")){
     WinnerIsX ();  
    }
    if (seven.equals ("X") && eight.equals ("X") && nine.equals ("X")){
     WinnerIsX ();  
    }
    if (one.equals ("X") && four.equals ("X") && seven.equals ("X")){
     WinnerIsX ();  
    }
    if (two.equals ("X") && five.equals ("X") && eight.equals ("X")){
     WinnerIsX ();  
    }
    if (three.equals ("X") && six.equals ("X") && nine.equals ("X")){
     WinnerIsX ();  
    }
    if (three.equals ("X") && five.equals ("X") && seven.equals ("X")){
     WinnerIsX ();  
    }
    if (one.equals ("X") && five.equals ("X") && nine.equals ("X")){
     WinnerIsX ();  
    }
    
    //This is for the O player
    if (one.equals ("O") && two.equals ("O") && three.equals ("O")){ //All of these are basically the different winning combinations that O can have
     WinnerIsO ();  
    }
    if (four.equals ("O") && five.equals ("O") && six.equals ("O")){
     WinnerIsO ();  
    }
    if (seven.equals ("O") && eight.equals ("O") && nine.equals ("O")){
     WinnerIsO ();  
    }
    if (one.equals ("O") && four.equals ("O") && seven.equals ("O")){
     WinnerIsO ();  
    }
    if (two.equals ("O") && five.equals ("O") && eight.equals ("O")){
     WinnerIsO ();  
    }
    if (three.equals ("O") && six.equals ("O") && nine.equals ("O")){
     WinnerIsO ();  
    }
    if (three.equals ("O") && five.equals ("O") && seven.equals ("O")){
     WinnerIsO ();  
    }
    if (one.equals ("O") && five.equals ("O") && nine.equals ("O")){
     WinnerIsO ();  
    }

    }
    
     public void Tie (){ //It lets the user know if the game ended as a draw
    String one = jButton1.getText ();
    String two = jButton3.getText ();
    String three = jButton4.getText ();
    String four = jButton5.getText ();
    String five = jButton6.getText ();
    String six = jButton7.getText ();
    String seven = jButton8.getText ();
    String eight = jButton9.getText ();
    String nine = jButton10.getText ();
    
    if(one != "" && two != "" && three != "" && four != "" && five != "" && six != "" && seven != "" && eight != "" && nine != ""){
     //Basically this if statement is saying that if all of the buttons are occupied by a symbol and are not empty it means it is a draw
    JOptionPane.showMessageDialog(null, "DRAW!"); //This is to show the message DRAW! on the screen
    
    
     }
     }
     
    public void WinnerIsX (){
        
     JOptionPane.showMessageDialog(null, "THE WINNER IS X"); //This is let the user know X won
     }
    
    public void WinnerIsO (){
        JOptionPane.showMessageDialog(null, "THE WINNER IS O"); //This is let the user know O won
     
     }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TICTACTOE_BOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TICTACTOE_BOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TICTACTOE_BOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TICTACTOE_BOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TICTACTOE_BOARD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton resetButton;
    // End of variables declaration//GEN-END:variables
}
