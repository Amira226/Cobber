/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public class AnyProduct implements IProduct {
    
    //
    private String Name = "";
    public String GetProductName() { return Name; }
    public void SetProductName(String ProductName) { this.Name = ProductName; }

    private double Price = 0;
    public double GetProductPrice() { return Price; }
    public void SetProductPrice(int ProductPrice) { this.Price = ProductPrice; }

    public AnyProduct() {}

    public AnyProduct(String ProductName, double ProductPrice) {
        this.Name = ProductName;
        this.Price = ProductPrice;
    }

    @Override
    public String ProductName() {
        return GetProductName();
        
    }

    @Override
    public double ProductPrice() {
       return  GetProductPrice();

    }

    @Override
    public int Quantity() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
}
