/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public class Cart {
    
    public double Cart;// Cart is a screen, not a variable
    //public Object AddToCart(Object val){return Cart = val;}
    public double RemoveFromCart(double val){ return Cart -= val;}
    
    public static void AddToCart()
    { 
        //
        productInfo(slotCode);
        
    }

    private void productInfo(String slotCode) {
        // Each item/ button has its own slotCode, works similarly to an IP address
        // Like in the vendItem method, if statements are used. If slotCode= a1, it means it will seek for a hoodie, costing $20.
        //If the add button is clicked 7 times, the, quantity would go up by 7., creasing total costs
        // If by removing items, quantity=0, the whole printed statement is errased.
        /**
         * return ProductName()+" - "+ProductPrice()+" - "+product.AddQuantity()+ " - "+ (product.AddQuantity()*ProductPrice());
         * 
         */
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Cart()
    {
        
    }
    
    
}
