/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    
    //Controls the cash in the vault
    protected static Double Cash;
    protected static Double GetCash(){return Cash;}
    public static void SetCash(double val){Cash = val;}
    public static void AddCash(double val ){Cash += val;}
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        String slotCode="";
        
        Cart.AddToCart(slotCode);
        /**
         * double cost = QuantityInserted*slotCode.getPrice()
         * print -- slotCode.getName(),slotCode.getPrice() -- QuantityInserted -- cost;
         * 
         * while (buttonIsClicked==TRUE)
         * {
         * QUANTITY++;
         * }
         * if (Quantity>0){print -- name,price of the product}
         * 
         */
        
        Cart.GetToCart(){
    
        /**
         * TotalCost = sum of all cost(i);i = 0,1,3,...,n = slotCode
         * sloCode  can be a1, a2, a3, etc. They all are part of an array of objects, each with their own characteristics, but primarily,name and price
         */
    
        }
        
        
    }
    
}
