/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eliasnkuansambu
 */
public interface IProduct {
    // This interface provides a description of the products.
    
    //Name includes the description of the product
    //Eg. Red Hoodie XXL 
    String ProductName();
    
    double ProductPrice();
    
    int Quantity();
    
}
